package com.shihuc.dbconn.pojo;

import java.io.Serializable;
import java.util.Date;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.DBRef;
import org.springframework.data.mongodb.core.mapping.Document;

/**
 * ClassName:OrganizationContent
 * dateTime:2019年1月21日下午1:55:24
 * @author workmac
 * @date 2019/01/21
 */
@Document
public class OrganizationContent implements Serializable{

    private static final long serialVersionUID = 1L;
//	@Id
//	String id;
	@DBRef
	public Organization organization;
	@DBRef
	public ContentHistory contentHistory;
	public Date createdAt;
	/*public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}*/
	public Organization getOrganization() {
		return organization;
	}
	public void setOrganization(Organization organization) {
		this.organization = organization;
	}
	public ContentHistory getContentHistory() {
		return contentHistory;
	}
	public void setContentHistory(ContentHistory contentHistory) {
		this.contentHistory = contentHistory;
	}
	public Date getCreatedAt() {
		return createdAt;
	}
	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}
	
}
