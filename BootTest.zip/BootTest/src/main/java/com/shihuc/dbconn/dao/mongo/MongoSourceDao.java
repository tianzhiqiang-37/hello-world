/**
 * 
 */
package com.shihuc.dbconn.dao.mongo;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Repository;
import com.shihuc.dbconn.pojo.mongo.MongoFilter;
import com.shihuc.dbconn.pojo.mongo.MongoSource;

/**
 * @author 田
 * 2019年1月25日
 */
@Repository
public class MongoSourceDao {

    @Autowired
    MongoTemplate mongoTemplate;
    
    public void addSource(MongoSource sour){
        mongoTemplate.insert(sour);
    }
    
    
    public List<MongoSource> getAllsOURCE(){
        return mongoTemplate.findAll(MongoSource.class);
    }
    
    public void setlisSource(List<MongoSource> soulist){
        mongoTemplate.insertAll(soulist);
    }
    
}
