/**
 * 
 */
package com.shihuc.dbconn.util;

import java.util.ArrayList;
import java.util.List;
import com.shihuc.dbconn.pojo.Author;
import com.shihuc.dbconn.pojo.Condition;
import com.shihuc.dbconn.pojo.ContentDetail;
import com.shihuc.dbconn.pojo.ContentDetailImage;
import com.shihuc.dbconn.pojo.MediaVo;
import com.shihuc.dbconn.pojo.mongo.MongoLanguage;
import com.shihuc.dbconn.pojo.mongo.MongoOrganization;

/**
 * @author 田
 * 2019年1月25日
 */
public class ProduceList {
    
    public static List<Author> proAuthorList(){
        List<Author> liau=new ArrayList<Author>();
        Author a1=new Author();
        Author a2=new Author();
        Author a3=new Author();
        a1.setName("田");a1.setEmail("tian@dwnews.com");
        a2.setName("林岩");a2.setEmail("lin@dwnews.com");
        a3.setName("测试");a3.setEmail("ce@163.com");
        liau.add(a1);
        liau.add(a2);
        liau.add(a3);
        return liau;
    }
    
    public static List<MediaVo> procdetaiImage(){
        MediaVo cimg=new MediaVo();
        cimg.setCaption("圖片標題圖片標題圖片標題圖片標題");
        cimg.setUrl("https://cdn.hk01.com/di/media/images/2332599/org/f0cfa0dc347577f9e2a1c991aa5b0e5b.jpg/bjdzisl7zzy0D1Yr8tBhSwiF_xjPtzRZWqjxR1qo8Uc?v=w1920r16_9");
        
        MediaVo cimg_1=new MediaVo();
        cimg_1.setCaption("图片图片啊啊啊图片图片啊啊啊图片图片啊啊啊");
        cimg_1.setUrl("https://cdn.hk01.com/di/media/images/2332599/org/f0cfa0dc347577f9e2a1c991aa5b0e5b.jpg");
        List<MediaVo> liimg=new ArrayList<MediaVo>();
        liimg.add(cimg);
        liimg.add(cimg_1);
        return liimg;
    }
    
    
    public static List<ContentDetail> proDetail(){
        List<ContentDetail> litobt= new ArrayList<ContentDetail>();
        ContentDetail c1=new ContentDetail();
        c1.setImage(procdetaiImage());
        c1.setText("内外内容");
        c1.setType("textImage");
        
        ContentDetail c2=new ContentDetail();
        c2.setImage(procdetaiImage());
        c2.setText("内文啊啊啊啊啊啊啊啊啊");
        c2.setType("tepic");
        
        litobt.add(c1);
        litobt.add(c2);
        return litobt;
    }
    
    public static List<MongoOrganization> proOrganization(){
        List<MongoOrganization> litobt= new ArrayList<MongoOrganization>();
        MongoOrganization m1= new MongoOrganization();
        MongoOrganization m2= new MongoOrganization();
        MongoOrganization m3= new MongoOrganization();
        m1.setName("HK01");
        m2.setName("DW-NEWS");
        m3.setName("TW01");
        litobt.add(m1);
        litobt.add(m2);
        litobt.add(m3);
        return litobt;
    }
    
    public static List<MongoLanguage> proLanguage(){
        List<MongoLanguage> litlangu= new ArrayList<MongoLanguage>();
        MongoLanguage la1=new MongoLanguage();
        MongoLanguage la3=new MongoLanguage();
        MongoLanguage la4=new MongoLanguage();
        la1.setName("zh_cn");
        la1.setLanguageId(1);
        la3.setName("zh_en");
        la3.setLanguageId(2);
        la4.setName("en_en");
        la4.setLanguageId(3);
        litlangu.add(la1);
        litlangu.add(la3);
        litlangu.add(la4);
        return litlangu;
    }
    
    public static List<Condition> proCondition(){
        List<Condition> condi= new ArrayList<Condition>();
        List<String> li=new ArrayList<String>();
        li.add("田志强");
        li.add("田2号");
        li.add("田3号");
        li.add("田4号");
        li.add("田5号");
        List<String> keyword=new ArrayList<String>();
        keyword.add("韩国总统 ");    
        keyword.add("文在寅访华");
        keyword.add("文在寅北大发表演讲");
        keyword.add("中韩关系");
        keyword.add("多维新闻");
        
        Condition c1=new Condition();
        c1.setSource("HK01");
        c1.setAuthor(li);
        c1.setKeyword(keyword);
        c1.setCategory("一类");
        c1.setLanguage("zh_cn");
        Condition c2=new Condition();
        c2.setSource("TW01");
        c2.setAuthor(li);
        c2.setKeyword(keyword);
        c2.setCategory("二类");
        c2.setLanguage("zh_en");
        condi.add(c1);
        condi.add(c2);
        return condi;
    }
    
    
    public static List<ContentDetailImage> proContentDetailImage(){
        List<ContentDetailImage> imglist=new ArrayList<ContentDetailImage>();
        ContentDetailImage img1=new ContentDetailImage();
        ContentDetailImage img2=new ContentDetailImage();
        ContentDetailImage img3=new ContentDetailImage();
        img1.setUrl("http://pic5.dwnews.net/20160106/e9b36acc64ec594e7bfc329eaa415dc1_h.jpg");
        img1.setCaption("图集图片");
        img2.setUrl("http://pic7.dwnews.net/20150304/f2ae6390ff8375fb1a818c4c7b092a2d_w.jpg");
        img2.setCaption("普通内文图片");
        img3.setUrl("http://pic4.dwnews.net/20151219/f6fb3dade288f1d3fa41c10f50d27231_w.jpg");
        img3.setCaption("普通图");
        imglist.add(img1);
        imglist.add(img2);
        imglist.add(img3);
        
        return imglist;
    }
    
    public static List<MediaVo> proImage(){
        List<MediaVo> imglist=new ArrayList<MediaVo>();
        MediaVo img1=new MediaVo();
        MediaVo img2=new MediaVo();
        MediaVo img3=new MediaVo();
        img1.setUrl("http://pic5.dwnews.net/20160106/e9b36acc64ec594e7bfc329eaa415dc1_h.jpg");
        img1.setCaption("图集图片");
        img2.setUrl("http://pic7.dwnews.net/20150304/f2ae6390ff8375fb1a818c4c7b092a2d_w.jpg");
        img2.setCaption("普通内文图片");
        img3.setUrl("http://pic4.dwnews.net/20151219/f6fb3dade288f1d3fa41c10f50d27231_w.jpg");
        img3.setCaption("普通图");
        imglist.add(img1);
        imglist.add(img2);
        imglist.add(img3);
        
        return imglist;
    }
    

    public static List<ContentDetail> proContentDetail(){
        List<ContentDetail> detaillist=new ArrayList<ContentDetail>();
        ContentDetail cd1=new ContentDetail();
        ContentDetail cd2=new ContentDetail();
        ContentDetail cd3=new ContentDetail();
        cd1.setText("textImage");
        cd1.setType("文章内文");
        cd1.setImage(proImage());
        cd2.setText("contentImage");
        cd2.setType("内容图片");
        cd2.setImage(proImage());
        cd3.setText("images");
        cd3.setType("图集图片");
        cd3.setImage(proImage());
        detaillist.add(cd1);
        detaillist.add(cd2);
        detaillist.add(cd3);
        return detaillist;
    }
}
