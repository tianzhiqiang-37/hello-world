/**
 * 
 */
package com.shihuc.dbconn.pojo.mongo;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import com.shihuc.dbconn.pojo.Language;

/**
 * @author 田
 * 2019年1月26日
 */
@Document(collection = "language")
public class MongoLanguage extends Language{
    
    private static final long serialVersionUID = 1L;
    @Id
    private String id;
    
    public String getId() {
        return id;
    }
    
    public MongoLanguage() {}

    public MongoLanguage(String name, Integer languageId) {
        this.name = name;
        this.languageId = languageId;
    }
}
