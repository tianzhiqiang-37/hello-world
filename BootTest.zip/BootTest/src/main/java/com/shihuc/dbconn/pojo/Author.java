package com.shihuc.dbconn.pojo;

import java.io.Serializable;

/**
 * 作者
 * ClassName:Author
 * dateTime:2018年12月17日下午2:41:42
 * @author workmac
 * @date 2018/12/17
 */
public class Author implements Serializable{

	
	String name;	//作者名称
	String email;	//作者邮箱
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
}
