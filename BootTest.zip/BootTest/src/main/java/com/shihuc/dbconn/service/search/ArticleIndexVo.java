package com.shihuc.dbconn.service.search;

import java.io.Serializable;
import java.util.List;
import java.util.Map;
import org.springframework.data.annotation.Id;
import org.springframework.data.elasticsearch.annotations.Document;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.shihuc.dbconn.pojo.Author;

/**
 * ClassName:ArticleIndexVo
 * StringTime:2018年12月20日下午4:05:42
 * @author workmac
 * @String 2018/12/20
 */
@Document(indexName="exchange",type="_doc")
public class ArticleIndexVo implements  Serializable{

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	@Id
	String id;							//文章表主键
	String contentId;					//文章ID
	String title;						//标题
	String description;					//摘要信息
	String sources;						//来源
	Long version;						//版本
	Long fromVersion;
	String signature;					//签名
	String language;                   //语言
	String status;						//状态，是否隐藏
	Long updatedAt;						//修改时间
	Long createdAt;						//修改时间
	Long publishedStart;					//发布时间
	Long publishedEnd;					//发布时间
	String tags;					//标签数组  或 关键字
	String category;				//类型 频道数组
	Boolean locked;
	String lockedBy;
	String versionStatus;
	String originalId;
	Object meta;						//其他
	List<Author> authors;				//作者
	
	/* (non-Javadoc)
	 * @see com.dwnews.content.exchange.search.model.FsmIndexEntity#getId()
	 */
	public String getId() {
		
		return id;
	}
	
	public void setId(String id) {
		this.id = id;
	}

	public String getContentId() {
		return contentId;
	}

	public void setContentId(String contentId) {
		this.contentId = contentId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getSources() {
	    return sources;
    }
  
    public void setSources(String sources) {
        this.sources = sources;
    }
  
    public Long getVersion() {
		return version;
	}

	public void setVersion(Long version) {
		this.version = version;
	}

	public String getSignature() {
		return signature;
	}

	public void setSignature(String signature) {
		this.signature = signature;
	}

	public String getLanguage() {
		return language;
	}

	public void setLanguage(String language) {
		this.language = language;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	
	public Long getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Long updatedAt) {
        this.updatedAt = updatedAt;
    }

    public Long getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Long createdAt) {
        this.createdAt = createdAt;
    }

    public Long getPublishedStart() {
        return publishedStart;
    }

    public void setPublishedStart(Long publishedStart) {
        this.publishedStart = publishedStart;
    }

    public Long getPublishedEnd() {
        return publishedEnd;
    }

    public void setPublishedEnd(Long publishedEnd) {
        this.publishedEnd = publishedEnd;
    }

    public String getTags() {
		return tags;
	}

	public void setTags(String tags) {
		this.tags = tags;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public Object getMeta() {
		return meta;
	}

	public void setMeta(Object meta) {
		this.meta = meta;
	}

    public List<Author> getAuthors() {
		return authors;
	}

	public void setAuthors(List<Author> authors) {
		this.authors = authors;
	}
	
	public Boolean getLocked() {
      return locked;
    }
  
    public void setLocked(Boolean locked) {
      this.locked = locked;
    }
  
    public String getLockedBy() {
      return lockedBy;
    }
  
    public void setLockedBy(String lockedBy) {
      this.lockedBy = lockedBy;
    }
  
    public String getVersionStatus() {
      return versionStatus;
    }
  
    public void setVersionStatus(String versionStatus) {
      this.versionStatus = versionStatus;
    }
    
    public Long getFromVersion() {
        return fromVersion;
    }

    public void setFromVersion(Long fromVersion) {
        this.fromVersion = fromVersion;
    }

    public String getOriginalId() {
        return originalId;
    }

    public void setOriginalId(String originalId) {
        this.originalId = originalId;
    }

    /* (non-Javadoc)
	 * @see com.dwnews.content.exchange.search.model.FsmIndexEntity#toMapObject()
	 */
	@SuppressWarnings("unchecked")
    public Map<String, Object> toMapObject() {
		ObjectMapper objectMapper = new ObjectMapper();
		return objectMapper.convertValue(this, Map.class);
	}
	
}
