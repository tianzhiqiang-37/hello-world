/**
 * 
 */
package com.shihuc.dbconn.pojo.mongo;

import java.util.Date;
import java.util.List;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import com.shihuc.dbconn.pojo.Condition;
import com.shihuc.dbconn.pojo.Filter;
import com.shihuc.dbconn.pojo.User;

/**
 * @author 田
 * 2019年1月25日
 */
@Document(collection = "filter")
public class MongoFilter extends Filter{

    private static final long serialVersionUID = 1L;
    
    @Id
    private String id;
    
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public MongoFilter() {}

    public MongoFilter(String name, String status, User createdBy, Date createdAt, Date updatedAt,
            User updateBy, List<Condition> conditions) {
        super();
        this.name = name;
        this.status = status;
        this.createdBy = createdBy;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
        this.updateBy = updateBy;
        this.conditions = conditions;
    }
}
