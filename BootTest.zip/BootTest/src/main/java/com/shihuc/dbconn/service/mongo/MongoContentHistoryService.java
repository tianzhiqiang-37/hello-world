/**
 * 
 */
package com.shihuc.dbconn.service.mongo;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.shihuc.dbconn.dao.mongo.MongoContentHistoryDao;
import com.shihuc.dbconn.pojo.mongo.MongoContentHistory;

/**
 * @author 田
 * 2019年1月26日
 */
@Service("contentHistoryService")
public class MongoContentHistoryService {

    @Autowired
    MongoContentHistoryDao   contentHistoryDao;
    
    public void addContentHistory(MongoContentHistory conHistory){
        contentHistoryDao.addContentHistory(conHistory);
    }
    
    public List<MongoContentHistory> getAllContent(){
        return contentHistoryDao.getAllContentHistory();
    }
    
    public void updateContentHistory(MongoContentHistory conHistory){
        contentHistoryDao.updateContentHistory(conHistory);
    }
    
    public void setListContentHistory(List<MongoContentHistory> contentHislist){
        contentHistoryDao.setListContentHistory(contentHislist);
    }
    
}
