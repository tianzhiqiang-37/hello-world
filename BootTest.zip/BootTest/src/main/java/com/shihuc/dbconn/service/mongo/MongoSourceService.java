/**
 * 
 */
package com.shihuc.dbconn.service.mongo;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.shihuc.dbconn.dao.mongo.MongoSourceDao;
import com.shihuc.dbconn.pojo.mongo.MongoSource;

/**
 * @author 田
 * 2019年1月25日
 */
@Service("mongoSourceService")
public class MongoSourceService {
    
    @Autowired
    MongoSourceDao mongoSourceDao;
    
    public void addSource(MongoSource sour){
        mongoSourceDao.addSource(sour);
    }

    public List<MongoSource> getAllsOURCE(){
        return mongoSourceDao.getAllsOURCE();
    }
    
    public void setlisSource(List<MongoSource> soulist){
        mongoSourceDao.setlisSource(soulist);
    }
}
