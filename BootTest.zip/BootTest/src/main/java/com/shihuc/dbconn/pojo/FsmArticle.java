/**
 * 
 */
package com.shihuc.dbconn.pojo;

/**
 * @author 田
 * 2019年1月25日
 */
public class FsmArticle {
    
//    public String id;
    
    public String filetype;
    public Integer status;
    public String title; 
    public String showTitle;
    public String author;
    public String digest; 
    public String content;
    public String keywords;
    public String tags;
    public String submitTime; 
    public String publishTime; 
    public String showTime;
    public String lastmodifyTime;
    public String lastmodify;
    public String source; 
    public String articleSource;
    public String address;
    public String url;
    public String sortIds; 
    public Integer templateId;
    public String signname;
    public String relevantPhoto;
    public Integer imgNum; 
    public Integer isShowDiscuss;
    public Integer isDiscuss;
    public String previousUrl;
    public String nextUrl;
    public String ext1Title;
    public String ext1Url;
    public String ext2Title;
    public String ext2Url;
    public Integer articleType;
    public Integer isValid;
    public String facebookCode;
    public String ikey;
    public String producer;
    public String headImage; 
    public String iSSN; 
    public String sharePhoto;
    public String gifPhoto;
    public String photosType;
//    PUBLIC STRING GETID() {
//        RETURN ID;
//    }
//    PUBLIC VOID SETID(STRING ID) {
//        THIS.ID = ID;
//    }
    public String getFiletype() {
        return filetype;
    }
    public void setFiletype(String filetype) {
        this.filetype = filetype;
    }
    public Integer getStatus() {
        return status;
    }
    public void setStatus(Integer status) {
        this.status = status;
    }
    public String getTitle() {
        return title;
    }
    public void setTitle(String title) {
        this.title = title;
    }
    public String getShowTitle() {
        return showTitle;
    }
    public void setShowTitle(String showTitle) {
        this.showTitle = showTitle;
    }
    public String getAuthor() {
        return author;
    }
    public void setAuthor(String author) {
        this.author = author;
    }
    public String getDigest() {
        return digest;
    }
    public void setDigest(String digest) {
        this.digest = digest;
    }
    public String getContent() {
        return content;
    }
    public void setContent(String content) {
        this.content = content;
    }
    public String getKeywords() {
        return keywords;
    }
    public void setKeywords(String keywords) {
        this.keywords = keywords;
    }
    public String getTags() {
        return tags;
    }
    public void setTags(String tags) {
        this.tags = tags;
    }
    public String getSubmitTime() {
        return submitTime;
    }
    public void setSubmitTime(String submitTime) {
        this.submitTime = submitTime;
    }
    public String getPublishTime() {
        return publishTime;
    }
    public void setPublishTime(String publishTime) {
        this.publishTime = publishTime;
    }
    public String getShowTime() {
        return showTime;
    }
    public void setShowTime(String showTime) {
        this.showTime = showTime;
    }
    public String getLastmodifyTime() {
        return lastmodifyTime;
    }
    public void setLastmodifyTime(String lastmodifyTime) {
        this.lastmodifyTime = lastmodifyTime;
    }
    public String getLastmodify() {
        return lastmodify;
    }
    public void setLastmodify(String lastmodify) {
        this.lastmodify = lastmodify;
    }
    public String getSource() {
        return source;
    }
    public void setSource(String source) {
        this.source = source;
    }
    public String getArticleSource() {
        return articleSource;
    }
    public void setArticleSource(String articleSource) {
        this.articleSource = articleSource;
    }
    public String getAddress() {
        return address;
    }
    public void setAddress(String address) {
        this.address = address;
    }
    public String getUrl() {
        return url;
    }
    public void setUrl(String url) {
        this.url = url;
    }
    public String getSortIds() {
        return sortIds;
    }
    public void setSortIds(String sortIds) {
        this.sortIds = sortIds;
    }
    public Integer getTemplateId() {
        return templateId;
    }
    public void setTemplateId(Integer templateId) {
        this.templateId = templateId;
    }
    public String getSignname() {
        return signname;
    }
    public void setSignname(String signname) {
        this.signname = signname;
    }
    public String getRelevantPhoto() {
        return relevantPhoto;
    }
    public void setRelevantPhoto(String relevantPhoto) {
        this.relevantPhoto = relevantPhoto;
    }
    public Integer getImgNum() {
        return imgNum;
    }
    public void setImgNum(Integer imgNum) {
        this.imgNum = imgNum;
    }
    public Integer getIsShowDiscuss() {
        return isShowDiscuss;
    }
    public void setIsShowDiscuss(Integer isShowDiscuss) {
        this.isShowDiscuss = isShowDiscuss;
    }
    public Integer getIsDiscuss() {
        return isDiscuss;
    }
    public void setIsDiscuss(Integer isDiscuss) {
        this.isDiscuss = isDiscuss;
    }
    public String getPreviousUrl() {
        return previousUrl;
    }
    public void setPreviousUrl(String previousUrl) {
        this.previousUrl = previousUrl;
    }
    public String getNextUrl() {
        return nextUrl;
    }
    public void setNextUrl(String nextUrl) {
        this.nextUrl = nextUrl;
    }
    public String getExt1Title() {
        return ext1Title;
    }
    public void setExt1Title(String ext1Title) {
        this.ext1Title = ext1Title;
    }
    public String getExt1Url() {
        return ext1Url;
    }
    public void setExt1Url(String ext1Url) {
        this.ext1Url = ext1Url;
    }
    public String getExt2Title() {
        return ext2Title;
    }
    public void setExt2Title(String ext2Title) {
        this.ext2Title = ext2Title;
    }
    public String getExt2Url() {
        return ext2Url;
    }
    public void setExt2Url(String ext2Url) {
        this.ext2Url = ext2Url;
    }
    public Integer getArticleType() {
        return articleType;
    }
    public void setArticleType(Integer articleType) {
        this.articleType = articleType;
    }
    public Integer getIsValid() {
        return isValid;
    }
    public void setIsValid(Integer isValid) {
        this.isValid = isValid;
    }
    public String getFacebookCode() {
        return facebookCode;
    }
    public void setFacebookCode(String facebookCode) {
        this.facebookCode = facebookCode;
    }
    public String getIkey() {
        return ikey;
    }
    public void setIkey(String ikey) {
        this.ikey = ikey;
    }
    public String getProducer() {
        return producer;
    }
    public void setProducer(String producer) {
        this.producer = producer;
    }
    public String getHeadImage() {
        return headImage;
    }
    public void setHeadImage(String headImage) {
        this.headImage = headImage;
    }
    public String getiSSN() {
        return iSSN;
    }
    public void setiSSN(String iSSN) {
        this.iSSN = iSSN;
    }
    public String getSharePhoto() {
        return sharePhoto;
    }
    public void setSharePhoto(String sharePhoto) {
        this.sharePhoto = sharePhoto;
    }
    public String getGifPhoto() {
        return gifPhoto;
    }
    public void setGifPhoto(String gifPhoto) {
        this.gifPhoto = gifPhoto;
    }
    public String getPhotosType() {
        return photosType;
    }
    public void setPhotosType(String photosType) {
        this.photosType = photosType;
    }
    
}
