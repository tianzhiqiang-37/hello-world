/**
 * 
 */
package com.shihuc.dbconn.pojo.mongo;

import java.util.List;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import com.shihuc.dbconn.pojo.Author;
import com.shihuc.dbconn.pojo.ContentDetail;
import com.shihuc.dbconn.pojo.ContentHistory;
import com.shihuc.dbconn.pojo.Organization;
import com.shihuc.dbconn.pojo.User;

/**
 * @author 田
 * 2019年1月26日
 */
@Document(collection = "contentHistory")
public class MongoContentHistory extends ContentHistory{

    private static final long serialVersionUID = 1L;

    @Id
    private String id;
    
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public MongoContentHistory() {}
    
    
    public MongoContentHistory(Long contentId, Long version, Long fromVersion, String source,
            Integer sourceId, List<Organization> exportedTo, String title, String description,
            String status, Long publishedStart, Long publishedEnd, List<String> tags,
            List<String> category, List<Author> authors, String language, String signature,
            List<ContentDetail> details, Integer versionStatus, Boolean locked, User lockedBy,
            Long createdAt, User createdBy, Long updatedAt, User updatedBy) {
        this.contentId = contentId;
        this.version = version;
        this.fromVersion = fromVersion;
        this.source = source;
        this.sourceId = sourceId;
        this.exportedTo = exportedTo;
        this.title = title;
        this.description = description;
        this.status = status;
        this.publishedStart = publishedStart;
        this.publishedEnd = publishedEnd;
        this.tags = tags;
        this.category = category;
        this.authors = authors;
        this.language = language;
        this.signature = signature;
        this.details = details;
        this.versionStatus = versionStatus;
        this.locked = locked;
        this.lockedBy = lockedBy;
        this.createdAt = createdAt;
        this.createdBy = createdBy;
        this.updatedAt = updatedAt;
        this.updatedBy = updatedBy;
    }
    
}
