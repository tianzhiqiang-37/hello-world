/**
 * 
 */
package com.shihuc.dbconn.dao.mongo;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Repository;
import com.shihuc.dbconn.pojo.mongo.MongoLanguage;

/**
 * @author 田
 * 2019年1月26日
 */
@Repository
public class MongoLanguageDao {

    @Autowired
    MongoTemplate mongoTemplate;
    
    public void addLanguage(MongoLanguage language){
        mongoTemplate.insert(language);
    }
    
    public List<MongoLanguage> getAllLanguage(){
        return mongoTemplate.findAll(MongoLanguage.class);
    }
    
    public void setListLanguage(List<MongoLanguage> langulist){
        mongoTemplate.insertAll(langulist);
    }
}
