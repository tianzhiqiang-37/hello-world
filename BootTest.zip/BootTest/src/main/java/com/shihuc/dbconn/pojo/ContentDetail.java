package com.shihuc.dbconn.pojo;
import java.io.Serializable;
import java.util.List;

/**
 * ClassName:ContentDetail
 * dateTime:2019年1月21日下午1:36:20
 * @author workmac
 * @date 2019/01/21
 */
public class ContentDetail implements Serializable{
	
    private static final long serialVersionUID = 1L;
    String type;
	String text;
	List<MediaVo> image;
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
	public List<MediaVo> getImage() {
		return image;
	}
	public void setImage(List<MediaVo> image) {
		this.image = image;
	}
	
}
