/**
 * 
 */
package com.shihuc.dbconn.service.mongo;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.shihuc.dbconn.dao.mongo.MongoOrganizationDao;
import com.shihuc.dbconn.pojo.Organization;
import com.shihuc.dbconn.pojo.mongo.MongoOrganization;

/**
 * @author 田
 * 2019年1月26日
 */
@Service("mongoOrganizationService")
public class MongoOrganizationService {
    
    @Autowired
    MongoOrganizationDao     organizationDao;
    
    public void addOrganization(MongoOrganizationDao organization){
        organizationDao.addOrganization(organization);
    }
    
    public List<MongoOrganization> getAllOrganization(){
        return organizationDao.getAllOrganization();
    }
    public List<Organization> getOrganization(){
        return organizationDao.getOrganization();
    }
    
    public void setListOrganization(List<MongoOrganization> orglist){
        organizationDao.setListOrganization(orglist);
    }

}
