/**
 * 
 */
package com.shihuc.dbconn.service.mongo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.shihuc.dbconn.dao.mongo.MongoArticleRepository;
import com.shihuc.dbconn.pojo.mongo.MongoArticle;

/**
 * @author 田
 * 2019年1月24日
 */
@Service("mongoArticleService")
public class MongoArticleService {

    @Autowired
    private MongoArticleRepository mongoArticle;
    
    public int addArticle(MongoArticle art){
        try {
            mongoArticle.addUser(art);
            return 1;
        } catch (Exception e) {
            return 0;        }
    }
}
