/**
 * 
 */
package com.shihuc.dbconn.service.mongo;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.shihuc.dbconn.dao.mongo.MongoNextIdDao;
import com.shihuc.dbconn.pojo.mongo.MongoNextId;

/**
 * @author 田
 * 2019年1月26日
 */
@Service("nextIdService")
public class MongoNextIdService {
    
    @Autowired
    MongoNextIdDao  mongoNextIdDao;

    public void addNextId(MongoNextId nextid){
        mongoNextIdDao.addNextId(nextid);
    }
    
    public List<MongoNextId> getAllNextId(){
        return mongoNextIdDao.getAllNextId();
    }
    
    public void setListNextId(List<MongoNextId> nextidlist){
        mongoNextIdDao.setListNextId(nextidlist);
    }
}
