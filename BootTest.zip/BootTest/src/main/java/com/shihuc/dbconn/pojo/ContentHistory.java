package com.shihuc.dbconn.pojo;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.DBRef;
import org.springframework.data.mongodb.core.mapping.Document;

/**
 * ClassName:ContentHistory
 * dateTime:2019年1月21日下午1:46:29
 * @author workmac
 * @date 2019/01/21
 */
@Document
public class ContentHistory implements Serializable{

    private static final long serialVersionUID = 1L;
    //	@Id
//	String id;
	public Long contentId;
	public Long version;
	public Long fromVersion;
	public String source;             //来源
    public Integer sourceId;
	@DBRef
	public List<Organization> exportedTo;
	public String title;
	public String description;
	public String status;
	public Long publishedStart;
	public Long publishedEnd;
	public List<String> tags;
	public List<String> category;
	public List<Author> authors;
	public String language;
	public String signature;
	public List<ContentDetail> details;
	public Integer versionStatus;
	public Boolean locked;
	@DBRef
	public User lockedBy;
	public Object createdAt;
	@DBRef 
	public User createdBy;
	public Object updatedAt;
	@DBRef
	public User updatedBy;
	/*public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}*/
	public Long getContentId() {
		return contentId;
	}
	public void setContentId(Long contentId) {
		this.contentId = contentId;
	}
	public Long getVersion() {
		return version;
	}
	public void setVersion(Long version) {
		this.version = version;
	}
	public Long getFromVersion() {
		return fromVersion;
	}
	public void setFromVersion(Long fromVersion) {
		this.fromVersion = fromVersion;
	}
	
	public String getSource() {
        return source;
    }
    public void setSource(String source) {
        this.source = source;
    }
    public Integer getSourceId() {
        return sourceId;
    }
    public void setSourceId(Integer sourceId) {
        this.sourceId = sourceId;
    }
	public List<Organization> getExportedTo() {
		return exportedTo;
	}
	public void setExportedTo(List<Organization> exportedTo) {
		this.exportedTo = exportedTo;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Long getPublishedStart() {
        return publishedStart;
    }
    public void setPublishedStart(Long publishedStart) {
        this.publishedStart = publishedStart;
    }
    public Long getPublishedEnd() {
        return publishedEnd;
    }
    public void setPublishedEnd(Long publishedEnd) {
        this.publishedEnd = publishedEnd;
    }
    public List<String> getTags() {
        return tags;
    }
    public void setTags(List<String> tags) {
        this.tags = tags;
    }
    public List<String> getCategory() {
		return category;
	}
	public void setCategory(List<String> category) {
		this.category = category;
	}
	public List<Author> getAuthors() {
		return authors;
	}
	public void setAuthors(List<Author> authors) {
		this.authors = authors;
	}
	public String getLanguage() {
		return language;
	}
	public void setLanguage(String language) {
		this.language = language;
	}
	public String getSignature() {
		return signature;
	}
	public void setSignature(String signature) {
		this.signature = signature;
	}
	public List<ContentDetail> getDetails() {
		return details;
	}
	public void setDetails(List<ContentDetail> details) {
		this.details = details;
	}
	public Integer getVersionStatus() {
		return versionStatus;
	}
	public void setVersionStatus(Integer versionStatus) {
		this.versionStatus = versionStatus;
	}
	public Boolean getLocked() {
		return locked;
	}
	public void setLocked(Boolean locked) {
		this.locked = locked;
	}
	public User getLockedBy() {
		return lockedBy;
	}
	public void setLockedBy(User lockedBy) {
		this.lockedBy = lockedBy;
	}
	public Object getCreatedAt() {
		return createdAt;
	}
	public void setCreatedAt(long createdAt) {
		this.createdAt = createdAt;
	}
	public User getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(User createdBy) {
		this.createdBy = createdBy;
	}
	public Object getUpdatedAt() {
		return updatedAt;
	}
	public void setUpdatedAt(Long updatedAt) {
		this.updatedAt = updatedAt;
	}
	public User getUpdatedBy() {
		return updatedBy;
	}
	public void setUpdatedBy(User updatedBy) {
		this.updatedBy = updatedBy;
	}
	
}
