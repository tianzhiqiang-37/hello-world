/**
 * 
 */
package com.shihuc.dbconn.service.mongo;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.shihuc.dbconn.dao.mongo.MongoOrgContentDao;
import com.shihuc.dbconn.pojo.mongo.MongoOrgaContent;

/**
 * @author 田
 * 2019年1月26日
 */
@Service("orgContentService")
public class MongoOrgContentService {
    
    @Autowired
    MongoOrgContentDao mongoOrgContentDao;
    
    public void addOrgContent(MongoOrgaContent orgContent){
        mongoOrgContentDao.addOrgContent(orgContent);
    }
    
    public List<MongoOrgaContent> getAllOrgContent(){
        return mongoOrgContentDao.getAllOrgContent();
    }
    
    public void setListLanguage(List<MongoOrgaContent> orgContentlist){
        mongoOrgContentDao.setListLanguage(orgContentlist);
    }

}
