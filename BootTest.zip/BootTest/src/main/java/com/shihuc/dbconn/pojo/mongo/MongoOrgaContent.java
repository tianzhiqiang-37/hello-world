/**
 * 
 */
package com.shihuc.dbconn.pojo.mongo;

import java.util.Date;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import com.shihuc.dbconn.pojo.ContentHistory;
import com.shihuc.dbconn.pojo.Organization;
import com.shihuc.dbconn.pojo.OrganizationContent;

/**
 * @author 田
 * 2019年1月26日
 */
@Document(collection = "organizationContent")
public class MongoOrgaContent extends OrganizationContent{

    private static final long serialVersionUID = 1L;

    @Id
    private String id;
    
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
    
    public MongoOrgaContent() {}
    
    public MongoOrgaContent(Organization organization, ContentHistory contentHistory,
            Date createdAt) {
        super();
        this.organization = organization;
        this.contentHistory = contentHistory;
        this.createdAt = createdAt;
    }
}
