package com.shihuc.dbconn.pojo;
import java.io.Serializable;
import java.util.Date;
import java.util.List;
import org.springframework.data.mongodb.core.mapping.DBRef;
import org.springframework.data.mongodb.core.mapping.Document;
import com.shihuc.dbconn.pojo.mongo.MongoFilter;

/**
 * 用户
 * ClassName:User
 * dateTime:2018年12月17日下午12:25:04
 * @author workmac
 * @date 2018/12/17
 */
@Document
public class User implements Serializable{

    private static final long serialVersionUID = 1L;
//	@Id
//	String id;
	public String userId;
	public String name;
	public String email;				//用户邮箱
	public String avatar;
	public String status;				//状态
	public Date createdAt;				//创建时间
	public Date updatedAt;				//修改时间
	public Object pemission;
	@DBRef
	public List<MongoFilter> filters;		//过滤器
	public String defaultFilter;
//	public String getId() {
//		return id;
//	}
//	public void setId(String id) {
//		this.id = id;
//	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getAvatar() {
		return avatar;
	}
	public void setAvatar(String avatar) {
		this.avatar = avatar;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Date getCreatedAt() {
		return createdAt;
	}
	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}
	public Date getUpdatedAt() {
		return updatedAt;
	}
	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}
	public Object getPemission() {
		return pemission;
	}
	public void setPemission(Object pemission) {
		this.pemission = pemission;
	}
	public List<MongoFilter> getFilters() {
		return filters;
	}
	public void setFilters(List<MongoFilter> filters) {
		this.filters = filters;
	}
	public String getDefaultFilter() {
		return defaultFilter;
	}
	public void setDefaultFilter(String defaultFilter) {
		this.defaultFilter = defaultFilter;
	}
	
}
