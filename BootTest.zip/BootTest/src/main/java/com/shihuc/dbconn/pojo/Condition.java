package com.shihuc.dbconn.pojo;

import java.io.Serializable;
import java.util.List;

/**
 * 查询条件 ClassName:Condition dateTime:2018年12月17日下午2:34:31
 *
 * @author workmac
 * @date 2018/12/17
 */
public class Condition implements Serializable {

    private static final long serialVersionUID = 1L;
    
  String id;
  String source;
  List<String> keyword;
  String category;
  List<String> author;
  String language;

  public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }

  public String getSource() {
    return source;
  }

  public void setSource(String source) {
    this.source = source;
  }

  public List<String> getKeyword() {
    return keyword;
  }

  public void setKeyword(List<String> keyword) {
    this.keyword = keyword;
  }

  public String getCategory() {
    return category;
  }

  public void setCategory(String category) {
    this.category = category;
  }

  public List<String> getAuthor() {
    return author;
  }

  public void setAuthor(List<String> author) {
    this.author = author;
  }

  public String getLanguage() {
    return language;
  }

  public void setLanguage(String language) {
    this.language = language;
  }

}
