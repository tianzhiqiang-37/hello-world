package com.shihuc.dbconn.service.mongo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.shihuc.dbconn.dao.mongo.MongoUserDao;
import com.shihuc.dbconn.pojo.User;
import com.shihuc.dbconn.pojo.mongo.MongoUser;

@Service("mongoUserService")
public class MongoUserService {

	@Autowired
	private MongoUserDao mongoUserRepository;
	
	public void addUser(MongoUser user){
		mongoUserRepository.addUser(user);
	}
	
	public MongoUser getUser(String username){
		return mongoUserRepository.getUser(username);
	}
	
	public User getUsera(String username){
	    return mongoUserRepository.getUser(username);
	}
}
