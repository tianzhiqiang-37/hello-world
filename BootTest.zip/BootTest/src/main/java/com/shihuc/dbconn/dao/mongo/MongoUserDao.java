/**
 * 
 */
package com.shihuc.dbconn.dao.mongo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;
import com.shihuc.dbconn.pojo.mongo.MongoUser;

/**
 * @author 田
 * 2019年1月25日
 */
@Repository
public class MongoUserDao {
    
    @Autowired
    MongoTemplate mongoTemplate;
    
    public void addUser(MongoUser user){
        mongoTemplate.insert(user);
    }
    
    public MongoUser getUser(String name){
        Query query = new Query();
        Criteria criteria = new Criteria();
        criteria = Criteria.where("name").is(name);
        query.addCriteria(criteria);
        return mongoTemplate.findOne(query, MongoUser.class);
    }

}
