/**
 * 
 */
package com.shihuc.dbconn.pojo.mongo;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import com.shihuc.dbconn.pojo.FsmArticle;

/**
 * @author 田
 * 2019年1月24日
 */
@Document(collection = "FsmArticleCopy")
public class MongoArticle extends FsmArticle{

    private static final long serialVersionUID = 1L;
    
    @Id
    private String id;
    
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public MongoArticle(String filetype, Integer status, String title, String showTitle,
            String author, String digest, String content, String keywords, String tags,
            String submitTime, String publishTime, String showTime, String lastmodifyTime,
            String lastmodify, String source, String articleSource, String address, String url,
            String sortIds, Integer templateId, String signname, String relevantPhoto,
            Integer imgNum, Integer isShowDiscuss, Integer isDiscuss, String previousUrl,
            String nextUrl, String ext1Title, String ext1Url, String ext2Title, String ext2Url,
            Integer articleType, Integer isValid, String facebookCode, String ikey,
            String producer, String headImage, String iSSN, String sharePhoto, String gifPhoto,
            String photosType) {
        super();
        this.filetype = filetype;
        this.status = status;
        this.title = title;
        this.showTitle = showTitle;
        this.author = author;
        this.digest = digest;
        this.content = content;
        this.keywords = keywords;
        this.tags = tags;
        this.submitTime = submitTime;
        this.publishTime = publishTime;
        this.showTime = showTime;
        this.lastmodifyTime = lastmodifyTime;
        this.lastmodify = lastmodify;
        this.source = source;
        this.articleSource = articleSource;
        this.address = address;
        this.url = url;
        this.sortIds = sortIds;
        this.templateId = templateId;
        this.signname = signname;
        this.relevantPhoto = relevantPhoto;
        this.imgNum = imgNum;
        this.isShowDiscuss = isShowDiscuss;
        this.isDiscuss = isDiscuss;
        this.previousUrl = previousUrl;
        this.nextUrl = nextUrl;
        this.ext1Title = ext1Title;
        this.ext1Url = ext1Url;
        this.ext2Title = ext2Title;
        this.ext2Url = ext2Url;
        this.articleType = articleType;
        this.isValid = isValid;
        this.facebookCode = facebookCode;
        this.ikey = ikey;
        this.producer = producer;
        this.headImage = headImage;
        this.iSSN = iSSN;
        this.sharePhoto = sharePhoto;
        this.gifPhoto = gifPhoto;
        this.photosType = photosType;
    }

    public MongoArticle() {}
}
