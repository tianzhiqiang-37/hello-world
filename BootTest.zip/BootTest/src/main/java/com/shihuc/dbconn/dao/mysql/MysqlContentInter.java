/**
 * 
 */
package com.shihuc.dbconn.dao.mysql;

import java.util.List;
import org.apache.ibatis.annotations.Select;
import com.shihuc.dbconn.pojo.mysql.MysqlContent;

/**
 * @author 田
 * 2019年1月25日
 */
public interface MysqlContentInter {
    
    @Select("")
    public List<MysqlContent> findAll();

}
