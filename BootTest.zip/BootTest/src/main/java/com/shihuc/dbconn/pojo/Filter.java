package com.shihuc.dbconn.pojo;
import java.io.Serializable;
import java.util.Date;
import java.util.List;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.DBRef;
import org.springframework.data.mongodb.core.mapping.Document;

/**
 * 过滤器
 * ClassName:Filters
 * dateTime:2018年12月17日下午2:32:37
 * @author workmac
 * @date 2018/12/17
 */
@Document
public class Filter implements Serializable {

    private static final long serialVersionUID = 1L;
    
//    @Id
//	String id;
	public String name;		//名称
	public String status;		//状态
	@DBRef
	public User createdBy;		//创建人
	public Date createdAt;		//创建时间
	public Date updatedAt;		//修改时间
	@DBRef
	public User updateBy;
	public List<Condition> conditions;	//条件
//	public String getId() {
//		return id;
//	}
//	public void setId(String id) {
//		this.id = id;
//	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public User getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(User createdBy) {
		this.createdBy = createdBy;
	}
	public Date getCreatedAt() {
		return createdAt;
	}
	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}
	public Date getUpdatedAt() {
		return updatedAt;
	}
	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}
	public User getUpdateBy() {
		return updateBy;
	}
	public void setUpdateBy(User updateBy) {
		this.updateBy = updateBy;
	}
	public List<Condition> getConditions() {
		return conditions;
	}
	public void setConditions(List<Condition> conditions) {
		this.conditions = conditions;
	}
	
}
