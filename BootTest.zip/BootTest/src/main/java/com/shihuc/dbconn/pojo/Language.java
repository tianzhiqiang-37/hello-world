package com.shihuc.dbconn.pojo;

import java.io.Serializable;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

/**
 * ClassName:Language
 * dateTime:2019年1月25日上午11:03:51
 * @author workmac
 * @date 2019/01/25
 */
@Document
public class Language implements Serializable{

//    @Id
//    String id;
    public String name;
    public Integer languageId;
   /* public String getId() {
        return id;
    }
    public void setId(String id) {
        this.id = id;
    }*/
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public Integer getLanguageId() {
        return languageId;
    }
    public void setLanguageId(Integer languageId) {
        this.languageId = languageId;
    }
    
}
