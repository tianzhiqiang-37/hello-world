package com.shihuc.dbconn;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.PropertySource;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.shihuc.dbconn.pojo.Author;
import com.shihuc.dbconn.pojo.InOrOutContentVo;
import com.shihuc.dbconn.pojo.Organization;
import com.shihuc.dbconn.pojo.mongo.MongoContent;
import com.shihuc.dbconn.pojo.mongo.MongoContentHistory;
import com.shihuc.dbconn.pojo.mongo.MongoFilter;
import com.shihuc.dbconn.pojo.mongo.MongoLanguage;
import com.shihuc.dbconn.pojo.mongo.MongoNextId;
import com.shihuc.dbconn.pojo.mongo.MongoOrgaContent;
import com.shihuc.dbconn.pojo.mongo.MongoOrganization;
import com.shihuc.dbconn.pojo.mongo.MongoSource;
import com.shihuc.dbconn.pojo.mongo.MongoUser;
import com.shihuc.dbconn.pojo.mysql.MysqlArticle;
import com.shihuc.dbconn.service.mongo.MongoContentHistoryService;
import com.shihuc.dbconn.service.mongo.MongoContentService;
import com.shihuc.dbconn.service.mongo.MongoFilterService;
import com.shihuc.dbconn.service.mongo.MongoLanguageService;
import com.shihuc.dbconn.service.mongo.MongoNextIdService;
import com.shihuc.dbconn.service.mongo.MongoOrgContentService;
import com.shihuc.dbconn.service.mongo.MongoOrganizationService;
import com.shihuc.dbconn.service.mongo.MongoSourceService;
import com.shihuc.dbconn.service.mongo.MongoUserService;
import com.shihuc.dbconn.service.mysql.MysqlRepositoryService;
import com.shihuc.dbconn.util.ProduceList;


/**
 * 
 * @author  shihuc
 * @date	Jan 29, 2016
 * 
 */
@SpringBootApplication
@PropertySource(value = "dbconn.properties")
public class DbConnApp 
{
	
   	public static void main(String[] args) throws Throwable {
      	
    	SpringApplication app = new SpringApplication(DbConnApp.class);
    	
		ApplicationContext ctx = app.run(args);		
		
		//mongoSourceService
//        MongoSourceService mongoSourceService = (MongoSourceService)ctx.getBean("mongoSourceService");
//        List<MongoSource> allsOURCE = mongoSourceService.getAllsOURCE();
        List<String> litag= new ArrayList<String>();
        litag.add("新闻");
        litag.add("视觉");
        litag.add("热点");
        Date date=new Date();
        long time = date.getTime();
        
		//查询article
		MysqlRepositoryService mysqlUserService = (MysqlRepositoryService)ctx.getBean("mysqlRepositoryService");
		List<MysqlArticle> findAll = mysqlUserService.findAll();
		System.out.println("Article____count:" + findAll.size());
		
		new Thread(new Runnable() {
            
            @Override
            public void run() {
                for (int j = 0; j < 4; j++) {
                    for (int i = 0; i < 500; i++) {
                        List<MysqlArticle> findBigCount = mysqlUserService.findBigCount(i);
                        for (MysqlArticle article : findBigCount) {
                            String agw =  "{\n" + 
                                    "  \"contentId\": 0,\n" + 
                                    "  \"version\": 1,\n" + 
                                    "  \"fromVersion\": 3,\n" + 
                                    "  \"source\": \"hk01\",\n" + 
                                    "  \"sourceId\": 234432,\n" + 
                                    "  \"title\": \""+article.getTitle()+"\",\n" + 
                                    "  \"description\": \""+article.getDigest()+"\",\n" + 
                                    "  \"authors\": [\n" + 
                                    "    {\n" + 
                                    "      \"name\": \""+article.getAuthor()+"\",\n" + 
                                    "      \"email\": \"chantaiman@hk01.com\"\n" + 
                                    "    }\n" + 
                                    "  ],\n" + 
                                    "  \"tags\": [\n" + 
                                    "    \""+article.getTags()+"\"\n" + 
                                    "  ],\n" + 
                                    "  \"categories\": [\n" + 
                                    "    \""+article.getFiletype()+"\"\n" + 
                                    "  ],\n" + 
                                    "  \"publishedStart\": "+time+",\n" + 
                                    "  \"publishedEnd\": 1577934245,\n" + 
                                    "  \"language\": \"zh_hk\",\n" + 
                                    "  \"content\": [\n" + 
                                    "    {\n" + 
                                    "      \"type\": \"textImage\",\n" + 
                                    "      \"text\": \"內agag文內文\",\n" + 
                                    "      \"images\": [\n" + 
                                    "        {\n" + 
                                    "          \"url\": \"https://cdn.hk01.com/di/media/images/2332599/org/f0cfa0dc347577f9e2a1c991aa5b0e5b.jpg/bjdzisl7zzy0D1Yr8tBhSwiF_xjPtzRZWqjxR1qo8Uc?v=w1920r16_9\",\n" + 
                                    "          \"caption\": \"圖片標題\"\n" + 
                                    "        }\n" + 
                                    "      ]\n" + 
                                    "    }\n" + 
                                    "  ]\n" + 
                                    "}";
                            gethttppost("http://10.12.33.54:8082/exchange/v1/content",agw);
                        }
                    }
                }
                
            }
		    
		}).start();
		
		
new Thread(new Runnable() {
            
            @Override
            public void run() {
                for (int j = 0; j < 4; j++) {
                    for (int i = 0; i < 500; i++) {
                        List<MysqlArticle> findBigCount = mysqlUserService.findBigCount(i);
                        for (MysqlArticle article : findBigCount) {
                            String agw =  "{\n" + 
                                    "  \"contentId\": 0,\n" + 
                                    "  \"version\": 1,\n" + 
                                    "  \"fromVersion\": 3,\n" + 
                                    "  \"source\": \"hk01\",\n" + 
                                    "  \"sourceId\": 234432,\n" + 
                                    "  \"title\": \""+article.getTitle()+"\",\n" + 
                                    "  \"description\": \""+article.getDigest()+"\",\n" + 
                                    "  \"authors\": [\n" + 
                                    "    {\n" + 
                                    "      \"name\": \""+article.getAuthor()+"\",\n" + 
                                    "      \"email\": \"chantaiman@hk01.com\"\n" + 
                                    "    }\n" + 
                                    "  ],\n" + 
                                    "  \"tags\": [\n" + 
                                    "    \""+article.getTags()+"\"\n" + 
                                    "  ],\n" + 
                                    "  \"categories\": [\n" + 
                                    "    \""+article.getFiletype()+"\"\n" + 
                                    "  ],\n" + 
                                    "  \"publishedStart\": "+time+",\n" + 
                                    "  \"publishedEnd\": 1577934245,\n" + 
                                    "  \"language\": \"zh_hk\",\n" + 
                                    "  \"content\": [\n" + 
                                    "    {\n" + 
                                    "      \"type\": \"textImage\",\n" + 
                                    "      \"text\": \"內agag文內文\",\n" + 
                                    "      \"images\": [\n" + 
                                    "        {\n" + 
                                    "          \"url\": \"https://cdn.hk01.com/di/media/images/2332599/org/f0cfa0dc347577f9e2a1c991aa5b0e5b.jpg/bjdzisl7zzy0D1Yr8tBhSwiF_xjPtzRZWqjxR1qo8Uc?v=w1920r16_9\",\n" + 
                                    "          \"caption\": \"圖片標題\"\n" + 
                                    "        }\n" + 
                                    "      ]\n" + 
                                    "    }\n" + 
                                    "  ]\n" + 
                                    "}";
                            gethttppost("http://10.12.33.54:8082/exchange/v1/content",agw);
                        }
                    }
                }
                
            }
            
        }).start();
		
        
        System.out.println("===============game OVER====================");
		//contentService接口
//		MongoContentService contentService = (MongoContentService)ctx.getBean("mongoContentService");
		/*List<MongoContent> allContent = contentService.getAllContent();
		System.out.println("content数据条数=========="+allContent.size());
		Date date=new Date();
		long time = date.getTime();
		for (MongoContent content : allContent) {
		    try {
		        content.setCreatedAt(content.getPublishedStart());
	            content.setUpdatedAt(content.getPublishedEnd());
	            contentService.updateContent(content);
            } catch (Exception e) {
               continue;
            }
		    
        }*/
		
		
		//contentHistory接口
//		MongoContentHistoryService contentHistoryService = (MongoContentHistoryService)ctx.getBean("contentHistoryService");
//		List<MongoContentHistory> allContentHis = contentHistoryService.getAllContent();
//		System.out.println("hirtory总条数============================="+allContentHis.size());
//		for (MongoContentHistory history : allContentHis) {
//		    Integer versionStatus = history.getVersionStatus();
//		    if(versionStatus%2==0){
//		        history.setVersionStatus(0);
//		    }else if(versionStatus%3==0){
//		        history.setVersionStatus(2);
//		    }else{
//		        history.setVersionStatus(3);
//		    }
//		    contentHistoryService.updateContentHistory(history);
//        }
//		System.out.println("修改结束====================================");
		
		
        
      //Organization 接口
//        MongoOrganizationService organizationService = (MongoOrganizationService)ctx.getBean("mongoOrganizationService");
//        List<Organization> allOrganization = organizationService.getOrganization();
        
        //userService接口
//        MongoUserService userService = (MongoUserService) ctx.getBean("mongoUserService");
        
        //languageService接口
//        MongoLanguageService languageService = (MongoLanguageService)ctx.getBean("mongoLanguageService");
//        List<MongoLanguage> language = languageService.getAllLanguage();
        
        //nextIdService接口
        /*MongoNextIdService nextIdService = (MongoNextIdService)ctx.getBean("nextIdService");
        for (int i = 0; i < 10; i++) {
            MongoNextId nex_i=new MongoNextId();
            nex_i.setNextId((long)findAll.get(i).getId());
            nextIdService.addNextId(nex_i);
        }*/
        
        //organizationContent接口
//        MongoOrgContentService orgcontentService = (MongoOrgContentService)ctx.getBean("orgContentService");
        /*for (int i = 0; i < 300; i++) {
            MongoOrgaContent orgcont_i=new MongoOrgaContent();
            if(i%2==0){
                orgcont_i.setOrganization(allOrganization.get(0));
            }else if(i%3==0){
                orgcont_i.setOrganization(allOrganization.get(1));
            }else{
                orgcont_i.setOrganization(allOrganization.get(2));
            }
            orgcont_i.setCreatedAt(new Date());
            orgcont_i.setContentHistory(allContentHis.get(i));
            orgcontentService.addOrgContent(orgcont_i);
        }*/
        
        
        
        /*
         * Content与CcontentHistory注入数据
         * Date date=new Date();
        long time = date.getTime();
        List<String> litag= new ArrayList<String>();
        litag.add("新闻");
        litag.add("视觉");
        litag.add("热点");
        
		for (MysqlArticle article : findAll) {
		    MongoContent mc_i=new MongoContent();
		    MongoContentHistory his_ii=new MongoContentHistory();
		    
            mc_i.setContentId((long) article.getId());
            if(article.getIsValid()==1){
                mc_i.setSource(allsOURCE.get(1));
                mc_i.setStatus("enable");
                mc_i.setLanguage(language.get(0).getName());
                
                his_ii.setSource(allsOURCE.get(1).getName());
                his_ii.setSourceId(1);
                his_ii.setStatus("enable");
                his_ii.setLanguage(language.get(0).getName());
                his_ii.setLocked(true);
                his_ii.setLockedBy(userService.getUsera("用户一"));
                his_ii.setCreatedBy(userService.getUsera("用户一"));
                his_ii.setUpdatedBy(userService.getUsera("用户一"));
                
                
            }else{
                mc_i.setSource(allsOURCE.get(0));
                mc_i.setStatus("dong");
                mc_i.setLanguage(language.get(1).getName());
                
                his_ii.setSource(allsOURCE.get(0).getName());
                his_ii.setSourceId(2);
                his_ii.setStatus("dong");
                his_ii.setLanguage(language.get(1).getName());
                his_ii.setLocked(false);
                his_ii.setLockedBy(userService.getUsera("用户二"));
                his_ii.setCreatedBy(userService.getUsera("用户二"));
                his_ii.setUpdatedBy(userService.getUsera("用户二"));
                
            }
            mc_i.setTitle(article.getTitle());
            mc_i.setDescription(article.getDigest());
            mc_i.setPublishedStart(time);
            mc_i.setPublishedEnd(time);
            mc_i.setTag(litag);
            mc_i.setCategory(litag);
            mc_i.setAuthors(ProduceList.proAuthorList());
            mc_i.setVersion((long) article.getId()*2);
            mc_i.setDetails(ProduceList.proContentDetail());
            mc_i.setCreatedAt(new Date());
            mc_i.setUpdatedAt(date);
            mc_i.setMetaPlaceholder("其他");
            int addArticle = contentService.addArticle(mc_i);
            System.out.print(addArticle);
            
            his_ii.setContentId((long) article.getId());
            his_ii.setVersion((long) article.getId()*2);
            his_ii.setFromVersion((long) article.getId()*2*3);
            his_ii.setExportedTo(allOrganization);
            his_ii.setTitle(article.getTitle());
            his_ii.setDescription(article.getDigest());
            his_ii.setPublishedStart(time);
            his_ii.setPublishedEnd(time);
            his_ii.setTags(litag);
            his_ii.setCategory(litag);
            his_ii.setAuthors(ProduceList.proAuthorList());
            his_ii.setSignature(article.getAuthor());
            his_ii.setDetails(ProduceList.proContentDetail());
            his_ii.setVersionStatus(article.getId()-59500000);
            his_ii.setCreatedAt(new Date());
            his_ii.setUpdatedAt(new Date());
            contentHistoryService.addContentHistory(his_ii);
        }*/
		
		
		
		
		//languageService接口
		/*MongoLanguageService languageService = (MongoLanguageService)ctx.getBean("mongoLanguageService");
		List<MongoLanguage> proLanguage = ProduceList.proLanguage();
		languageService.setListLanguage(proLanguage);*/
		
		
		
		/*过滤器---查询全部
		 * MongoFilterService filterService=(MongoFilterService) ctx.getBean("mongoFilterService");
		List<MongoFilter> allFil = filterService.getAllFil();*/
		
		/*user添加
		 * MongoUserService muserService = (MongoUserService) ctx.getBean("mongoUserService");
		MongoUser muser=new MongoUser();
		muser.setUserId("8888");
		muser.setName("用户二");
		muser.setEmail("asdfasd@dwnews.com");
		muser.setAvatar("笔名方法");
		muser.setStatus("有效");
		muser.setCreatedAt(new Date());
		muser.setUpdatedAt(new Date());
		muser.setPemission("这是啥");
		muser.setFilters(allFil);
		muser.setDefaultFilter("2号过滤器");
		muserService.addUser(muser);*/
		
		
		/*for (int i = 6; i < 8; i++) {
		    MongoFilter fil_i=new MongoFilter();
		    fil_i.setName(i+1+"号过滤器");
		    fil_i.setStatus("失效");
		    fil_i.setCreatedAt(new Date());
		    fil_i.setCreatedBy(muserService.getUser("用户一"));
		    fil_i.setUpdateBy(muserService.getUser("用户一"));
		    fil_i.setUpdatedAt(new Date());
		    fil_i.setConditions(conlist);
		    filterService.addFilter(fil_i);
        }*/
		
    }
   	
   	public static void gethttppost(String url, String param){
       	 PrintWriter out = null;
         BufferedReader in = null;
//         String charset = "UTF-8"; 
//         String result = "";
         try {
             URL realUrl = new URL(url);
             // 打开和URL之间的连接
             URLConnection conn = realUrl.openConnection();
             // 设置通用的请求属性
             conn.setRequestProperty("accept", "*/*");
             conn.setRequestProperty("connection", "Keep-Alive");
//             conn.setRequestProperty("user-agent","Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1;SV1)");
             conn.setRequestProperty("Content-Type","application/json; charset=UTF-8");
             // 发送POST请求必须设置如下两行
             conn.setDoOutput(true);
             conn.setDoInput(true);
             // 获取URLConnection对象对应的输出流
             out = new PrintWriter(conn.getOutputStream());
             // 发送请求参数
             out.print(param);
             // flush输出流的缓冲
             out.flush();
             // 定义BufferedReader输入流来读取URL的响应
             in = new BufferedReader(new InputStreamReader(conn.getInputStream(),"utf-8"));
//             String line;
//             while ((line = in.readLine()) != null) {
//                 result += line;
//             }
         } catch (Exception e) {
             System.out.println("发送 POST 请求出现异常！"+e);
             e.printStackTrace();
         }
         //使用finally块来关闭输出流、输入流
         finally{
             try{
                 if(out!=null){
                     out.close();
                 }
                 if(in!=null){
                     in.close();
                 }
             }
             catch(IOException ex){
                 ex.printStackTrace();
             }
         }
//         return result;
   	}
}
