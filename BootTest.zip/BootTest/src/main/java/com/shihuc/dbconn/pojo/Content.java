package com.shihuc.dbconn.pojo;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import org.springframework.data.mongodb.core.mapping.DBRef;
import org.springframework.data.mongodb.core.mapping.Document;

/**
 * 文章
 * ClassName:Article
 * dateTime:2018年12月17日下午1:45:34
 * @author workmac
 * @date 2018/12/17
 */
@Document
public class Content implements Serializable{

	
    private static final long serialVersionUID = 1L;
    //	@Id
//	String id;							//文章表主键
	public Long contentId;					//文章ID
//	@DBRef
	public String source;				//来源
	public String title;						//标题
	public String description;					//摘要信息
	public String status;						//状态，是否隐藏
	public Long publishedStart;
	public Long publishedEnd;
	public List<String> tags;					//标签数组  或 关键字
	public List<String> category;				//类型 频道数组
	public List<Author> authors;				//作者
	public String language;
	public Long version;						//版本
	public List<ContentDetail> details;
	public Object createdAt;
	public Object updatedAt;						//修改时间
	public Object metaPlaceholder;				//其他
//	public String getId() {
//		return id;
//	}
//	public void setId(String id) {
//		this.id = id;
//	}
	public Long getContentId() {
		return contentId;
	}
	public void setContentId(Long contentId) {
		this.contentId = contentId;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Long getPublishedStart() {
		return publishedStart;
	}
	public void setPublishedStart(Long publishedStart) {
		this.publishedStart = publishedStart;
	}
	public Long getPublishedEnd() {
		return publishedEnd;
	}
	public void setPublishedEnd(Long publishedEnd) {
		this.publishedEnd = publishedEnd;
	}
	public List<String> getTag() {
		return tags;
	}
	public void setTag(List<String> tags) {
		this.tags = tags;
	}
	public List<String> getCategory() {
		return category;
	}
	public void setCategory(List<String> category) {
		this.category = category;
	}
	public List<Author> getAuthors() {
		return authors;
	}
	public void setAuthors(List<Author> authors) {
		this.authors = authors;
	}
	public String getLanguage() {
		return language;
	}
	public void setLanguage(String language) {
		this.language = language;
	}
	public Long getVersion() {
		return version;
	}
	public void setVersion(Long version) {
		this.version = version;
	}
	public List<ContentDetail> getDetails() {
		return details;
	}
	public void setDetails(List<ContentDetail> litobt) {
		this.details = litobt;
	}
	public Object getCreatedAt() {
		return createdAt;
	}
	public void setCreatedAt(long createdAt) {
		this.createdAt = createdAt;
	}
	public Object getUpdatedAt() {
		return updatedAt;
	}
	public void setUpdatedAt(Long updatedAt) {
		this.updatedAt = updatedAt;
	}
	public Object getMetaPlaceholder() {
		return metaPlaceholder;
	}
	public void setMetaPlaceholder(Object metaPlaceholder) {
		this.metaPlaceholder = metaPlaceholder;
	}
	
}
