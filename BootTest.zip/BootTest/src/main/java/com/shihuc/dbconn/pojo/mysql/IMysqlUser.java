/**
 * 
 */
package com.shihuc.dbconn.pojo.mysql;

import com.shihuc.dbconn.pojo.User;

/**
 * @author 田
 * 2019年1月25日
 */

public class IMysqlUser extends User{

    private static final long serialVersionUID = 1L;

}
