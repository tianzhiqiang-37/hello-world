package com.shihuc.dbconn.pojo;

import java.io.Serializable;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

/**
 * ClassName:Organisation
 * dateTime:2019年1月11日下午2:25:22
 * @author workmac
 * @date 2019/01/11
 */
@Document
public class Organization implements Serializable{

	
    private static final long serialVersionUID = 1L;
//    @Id
//	String id;
	public String name;
//	public String getId() {
//		return id;
//	}
//	public void setId(String id) {
//		this.id = id;
//	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

}
