/**
 * 
 */
package com.shihuc.dbconn.pojo.mysql;

import java.util.Date;
import java.util.List;
import com.shihuc.dbconn.pojo.Author;
import com.shihuc.dbconn.pojo.Content;
import com.shihuc.dbconn.pojo.ContentDetail;
import com.shihuc.dbconn.pojo.Source;

/**
 * @author 田
 * 2019年1月25日
 */
public class MysqlContent extends Content{
    
    private static final long serialVersionUID = 1L;
    private int id;

    public Integer getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
    
    public MysqlContent(){};
    
    public MysqlContent(Long contentId, String source, String title, String description, String status,
            Long publishedStart, Long publishedEnd, List<String> tags, List<String> category,
            List<Author> authors, String language, Long version, List<ContentDetail> details,
            Long createdAt, Long updatedAt, Object metaPlaceholder) {
        super();
        this.contentId = contentId;
        this.source = source;
        this.title = title;
        this.description = description;
        this.status = status;
        this.publishedStart = publishedStart;
        this.publishedEnd = publishedEnd;
        this.tags = tags;
        this.category = category;
        this.authors = authors;
        this.language = language;
        this.version = version;
        this.details = details;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
        this.metaPlaceholder = metaPlaceholder;
    }


}
