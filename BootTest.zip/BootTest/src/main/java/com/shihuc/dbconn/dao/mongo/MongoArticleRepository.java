/**
 * 
 */
package com.shihuc.dbconn.dao.mongo;

import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Repository;
import com.shihuc.dbconn.pojo.mongo.MongoArticle;

/**
 * @author 田
 * 2019年1月24日
 */
@Repository
public class MongoArticleRepository {

    @Autowired
    MongoTemplate mongoTemplate;
    
    public void addUser(MongoArticle user){
        mongoTemplate.insert(user);
    }
}
