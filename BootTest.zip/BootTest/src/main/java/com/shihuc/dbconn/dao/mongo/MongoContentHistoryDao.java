/**
 * 
 */
package com.shihuc.dbconn.dao.mongo;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Repository;
import com.shihuc.dbconn.pojo.mongo.MongoContent;
import com.shihuc.dbconn.pojo.mongo.MongoContentHistory;

/**
 * @author 田
 * 2019年1月26日
 */
@Repository
public class MongoContentHistoryDao {
    
    @Autowired
    MongoTemplate mongoTemplate;

    public void addContentHistory(MongoContentHistory conHistory){
        mongoTemplate.insert(conHistory);
    }
    
    public List<MongoContentHistory> getAllContentHistory(){
        return mongoTemplate.findAll(MongoContentHistory.class);
    }
    
    public void updateContentHistory(MongoContentHistory conHistory){
        mongoTemplate.save(conHistory);
    }
    
    public void setListContentHistory(List<MongoContentHistory> contentHislist){
        mongoTemplate.insertAll(contentHislist);
    }
    
}
