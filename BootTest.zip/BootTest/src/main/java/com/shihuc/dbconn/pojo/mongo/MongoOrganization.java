/**
 * 
 */
package com.shihuc.dbconn.pojo.mongo;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import com.shihuc.dbconn.pojo.Organization;

/**
 * @author 田
 * 2019年1月26日
 */
@Document(collection = "organization")
public class MongoOrganization extends Organization{
    
    private static final long serialVersionUID = 1L;
    
    
    @Id
    private String id;
    
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public MongoOrganization() {}
    
    public MongoOrganization(String name) {
        this.name = name;
    }

}
