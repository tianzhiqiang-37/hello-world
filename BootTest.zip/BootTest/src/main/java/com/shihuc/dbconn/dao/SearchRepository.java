package com.shihuc.dbconn.dao;

import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;
import org.springframework.stereotype.Repository;
import com.shihuc.dbconn.service.search.ArticleIndexVo;

/**
 * ClassName:SearchRepository
 * dateTime:2019年1月25日下午4:39:50
 * @author workmac
 * @date 2019/01/25
 */
@Repository
public interface SearchRepository extends ElasticsearchRepository<ArticleIndexVo,String>{

}
