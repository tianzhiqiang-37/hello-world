/**
 * 
 */
package com.shihuc.dbconn.dao.mongo;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Repository;
import com.shihuc.dbconn.pojo.Filter;
import com.shihuc.dbconn.pojo.mongo.MongoFilter;

/**
 * @author 田
 * 2019年1月25日
 */
@Repository
public class MongoFilterDao {

    @Autowired
    MongoTemplate mongoTemplate;
    
    public void addFilter(MongoFilter filter){
        mongoTemplate.insert(filter);
    }
    
    public List<MongoFilter> getAllFil(){
        return mongoTemplate.findAll(MongoFilter.class);
    }
}
