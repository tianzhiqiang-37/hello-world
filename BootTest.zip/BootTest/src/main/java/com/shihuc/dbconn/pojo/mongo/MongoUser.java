/**
 * 
 */
package com.shihuc.dbconn.pojo.mongo;

import java.util.Date;
import java.util.List;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import com.shihuc.dbconn.pojo.User;

/**
 * @author 田
 * 2019年1月25日
 */
@Document(collection = "user")
public class MongoUser extends User{

    private static final long serialVersionUID = 1L;
    
    @Id
    private String id;
    
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public MongoUser() {}
    
    public MongoUser(String userId, String name, String email, String avatar, String status,
            Date createdAt, Date updatedAt, Object pemission, List<MongoFilter> filters,
            String defaultFilter) {
        this.userId = userId;
        this.name = name;
        this.email = email;
        this.avatar = avatar;
        this.status = status;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
        this.pemission = pemission;
        this.filters = filters;
        this.defaultFilter = defaultFilter;
    }

}
