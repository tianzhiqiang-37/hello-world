/**
 * 
 */
package com.shihuc.dbconn.service.mongo;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.shihuc.dbconn.dao.mongo.MongoFilterDao;
import com.shihuc.dbconn.pojo.mongo.MongoFilter;

/**
 * @author 田
 * 2019年1月25日
 */
@Service("mongoFilterService")
public class MongoFilterService {
    
    @Autowired
    MongoFilterDao mongoFilterDao;
    
    public void addFilter(MongoFilter filter){
        mongoFilterDao.addFilter(filter);
    }
    
    public List<MongoFilter> getAllFil(){
        List<MongoFilter> allFil = mongoFilterDao.getAllFil();
        return allFil;
    }

}
