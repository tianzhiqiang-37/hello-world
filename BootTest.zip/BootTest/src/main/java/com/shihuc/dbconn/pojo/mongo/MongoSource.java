/**
 * 
 */
package com.shihuc.dbconn.pojo.mongo;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import com.shihuc.dbconn.pojo.Source;

/**
 * @author 田
 * 2019年1月25日
 */
@Document(collection = "source")
public class MongoSource extends Source{

    private static final long serialVersionUID = 1L;

    @Id
    private String id;
    
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
    
    public MongoSource(){};
    
    public MongoSource(String name) {
        this.name = name;
    }
    
}
