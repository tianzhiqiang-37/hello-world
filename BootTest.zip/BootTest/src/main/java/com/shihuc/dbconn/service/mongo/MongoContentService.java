/**
 * 
 */
package com.shihuc.dbconn.service.mongo;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.shihuc.dbconn.dao.mongo.MongoContentRepository;
import com.shihuc.dbconn.pojo.mongo.MongoContent;
import com.shihuc.dbconn.pojo.mongo.MongoLanguage;

/**
 * @author 田
 * 2019年1月25日
 */
@Service("mongoContentService")
public class MongoContentService {
    
    @Autowired
    private MongoContentRepository mongoContentRepository;
    
    public int addArticle(MongoContent art){
        try {
            mongoContentRepository.addContent(art);
            return 1;
        } catch (Exception e) {
            return 0;        }
    }
    
    public List<MongoContent> getAllContent(){
        return mongoContentRepository.getAllContent();
    }
    
    public void updateContent(MongoContent art){
        mongoContentRepository.updateContent(art);
    }
    
    
    public void setListContent(List<MongoContent> contentlist){
        mongoContentRepository.setListContent(contentlist);
    }

}
