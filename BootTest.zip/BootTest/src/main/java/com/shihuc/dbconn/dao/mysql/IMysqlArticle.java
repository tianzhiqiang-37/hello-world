/**
 * 
 */
package com.shihuc.dbconn.dao.mysql;

import java.util.List;
import org.apache.ibatis.annotations.Select;
import com.shihuc.dbconn.pojo.mysql.MysqlArticle;

/**
 * @author 田
 * 2019年1月24日
 */
public interface IMysqlArticle {

    @Select("SELECT * FROM FSM_ARTICLE WHERE id = #{userId}")
    public MysqlArticle getUser(int userId);
    
    @Select("SELECT * FROM FSM_ARTICLE LIMIT 400,500")
    public List<MysqlArticle> findAll();
    
    
    @Select("SELECT * FROM FSM_ARTICLE LIMIT #{page},500")
    public List<MysqlArticle> findBigCount(int page);
}
