package com.shihuc.dbconn.pojo;

import java.util.List;

/**
 * ClassName:InOrOutContent
 * dateTime:2019年1月23日上午9:32:59
 * @author workmac
 * @date 2019/01/23
 */
public class InOrOutContentVo implements java.io.Serializable{

    private static final long serialVersionUID = 1L;
    //內容ID
    Long contentId;
    //版本
    Long version;
    //上一版本
    Long fromVersion; 
    //來源
    String source;
    //來源內容ID
    String sourceId;
    //標題
    String title;
    //撮要
    String description;
    //作者
    List<Author> authors;
    //標籤
    List<String> tags;
    //分類
    List<String> categories;
    //上線時間
    Long publishedStart;
    //下線時間
    Long publishedEnd;
    //語言
    String language;
    //內文
    List<String> content;
    public Long getContentId() {
        return contentId;
    }
    public void setContentId(Long contentId) {
        this.contentId = contentId;
    }
    public Long getVersion() {
        return version;
    }
    public void setVersion(Long version) {
        this.version = version;
    }
    public Long getFromVersion() {
        return fromVersion;
    }
    public void setFromVersion(Long fromVersion) {
        this.fromVersion = fromVersion;
    }
    public String getSource() {
        return source;
    }
    public void setSource(String source) {
        this.source = source;
    }
    public String getSourceId() {
        return sourceId;
    }
    public void setSourceId(String sourceId) {
        this.sourceId = sourceId;
    }
    public String getTitle() {
        return title;
    }
    public void setTitle(String title) {
        this.title = title;
    }
    public String getDescription() {
        return description;
    }
    public void setDescription(String description) {
        this.description = description;
    }
    public List<Author> getAuthors() {
        return authors;
    }
    public void setAuthors(List<Author> authors) {
        this.authors = authors;
    }
    public List<String> getTags() {
        return tags;
    }
    public void setTags(List<String> tags) {
        this.tags = tags;
    }
    public List<String> getCategories() {
        return categories;
    }
    public void setCategories(List<String> categories) {
        this.categories = categories;
    }
    public Long getPublishedStart() {
        return publishedStart;
    }
    public void setPublishedStart(Long publishedStart) {
        this.publishedStart = publishedStart;
    }
    public Long getPublishedEnd() {
        return publishedEnd;
    }
    public void setPublishedEnd(Long publishedEnd) {
        this.publishedEnd = publishedEnd;
    }
    public String getLanguage() {
        return language;
    }
    public void setLanguage(String language) {
        this.language = language;
    }
    public List<String> getContent() {
        return content;
    }
    public void setContent(List<String> content) {
        this.content = content;
    }
        
}
