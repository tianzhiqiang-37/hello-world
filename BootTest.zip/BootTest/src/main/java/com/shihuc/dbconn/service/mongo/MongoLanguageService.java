/**
 * 
 */
package com.shihuc.dbconn.service.mongo;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.shihuc.dbconn.dao.mongo.MongoLanguageDao;
import com.shihuc.dbconn.pojo.mongo.MongoLanguage;

/**
 * @author 田
 * 2019年1月26日
 */
@Service("mongoLanguageService")
public class MongoLanguageService {

    @Autowired
    MongoLanguageDao   languageDao;
    
    
    public void addLanguage(MongoLanguage language){
        languageDao.addLanguage(language);
    }
    
    public List<MongoLanguage> getAllLanguage(){
        return languageDao.getAllLanguage();
    }
    
    public void setListLanguage(List<MongoLanguage> langulist){
        languageDao.setListLanguage(langulist);
    }
}
