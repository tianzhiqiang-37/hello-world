/**
 * 
 */
package com.shihuc.dbconn.dao.mongo;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Repository;
import com.shihuc.dbconn.pojo.mongo.MongoNextId;

/**
 * @author 田
 * 2019年1月26日
 */
@Repository
public class MongoNextIdDao {

    @Autowired
    MongoTemplate mongoTemplate;
    
    public void addNextId(MongoNextId language){
        mongoTemplate.insert(language);
    }
    
    public List<MongoNextId> getAllNextId(){
        return mongoTemplate.findAll(MongoNextId.class);
    }
    
    public void setListNextId(List<MongoNextId> langulist){
        mongoTemplate.insertAll(langulist);
    }
}
