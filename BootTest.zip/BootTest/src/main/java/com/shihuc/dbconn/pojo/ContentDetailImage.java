package com.shihuc.dbconn.pojo;

import java.io.Serializable;

/**
 * ClassName:ContentDetailImage
 * dateTime:2019年1月21日下午1:37:45
 * @author workmac
 * @date 2019/01/21
 */
public class ContentDetailImage implements Serializable{
	
    private static final long serialVersionUID = 1L;
    String url;
	String caption; //图片标题
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public String getCaption() {
		return caption;
	}
	public void setCaption(String caption) {
		this.caption = caption;
	}
	
}
