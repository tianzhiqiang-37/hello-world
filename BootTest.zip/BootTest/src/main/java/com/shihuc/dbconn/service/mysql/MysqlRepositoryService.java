/**
 * 
 */
package com.shihuc.dbconn.service.mysql;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.shihuc.dbconn.dao.mysql.IMysqlArticle;
import com.shihuc.dbconn.pojo.mysql.MysqlArticle;

/**
 * @author 田
 * 2019年1月24日
 */
@Service("mysqlRepositoryService")
public class MysqlRepositoryService {
    
    @Autowired
    private IMysqlArticle mysqlArticl;
    

    public MysqlArticle getUser(int userId) {
        return mysqlArticl.getUser(userId);
    }
    
    public List<MysqlArticle> findAll(){
        return mysqlArticl.findAll();
    }
    
    public List<MysqlArticle> findBigCount(int page){
        List<MysqlArticle> findBigCount = mysqlArticl.findBigCount(page);
        return findBigCount;
    }

}
