/**
 * 
 */
package com.shihuc.dbconn.dao.mongo;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Repository;
import com.shihuc.dbconn.pojo.mongo.MongoContent;

/**
 * @author 田
 * 2019年1月25日
 */
@Repository
public class MongoContentRepository {
    
    @Autowired
    MongoTemplate mongoTemplate;

    public void addContent(MongoContent user){
        mongoTemplate.insert(user);
    }
    
    public List<MongoContent> getAllContent(){
        return mongoTemplate.findAll(MongoContent.class);
    }
    
    public void updateContent(MongoContent cont){
        mongoTemplate.save(cont);
    }
    
    public void setListContent(List<MongoContent> contentlist){
        mongoTemplate.insertAll(contentlist);
    }
    
}
