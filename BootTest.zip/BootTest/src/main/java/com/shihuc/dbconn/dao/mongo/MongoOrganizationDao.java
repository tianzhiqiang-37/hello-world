/**
 * 
 */
package com.shihuc.dbconn.dao.mongo;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Repository;
import com.shihuc.dbconn.pojo.Organization;
import com.shihuc.dbconn.pojo.mongo.MongoOrganization;

/**
 * @author 田
 * 2019年1月26日
 */
@Repository
public class MongoOrganizationDao {
    
    @Autowired
    MongoTemplate mongoTemplate;
    
    public void addOrganization(MongoOrganizationDao organization){
        mongoTemplate.insert(organization);
    }
    
    public List<MongoOrganization> getAllOrganization(){
        return mongoTemplate.findAll(MongoOrganization.class);
    }
    public List<Organization> getOrganization(){
        return mongoTemplate.findAll(Organization.class);
    }
    
    public void setListOrganization(List<MongoOrganization> orglist){
        mongoTemplate.insertAll(orglist);
    }

}
