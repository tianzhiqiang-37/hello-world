/**
 * 
 */
package com.shihuc.dbconn.dao.mongo;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Repository;
import com.shihuc.dbconn.pojo.mongo.MongoOrgaContent;

/**
 * @author 田
 * 2019年1月26日
 */
@Repository
public class MongoOrgContentDao {
    
    @Autowired
    MongoTemplate mongoTemplate;
    
    public void addOrgContent(MongoOrgaContent orgContent){
        mongoTemplate.insert(orgContent);
    }
    
    public List<MongoOrgaContent> getAllOrgContent(){
        return mongoTemplate.findAll(MongoOrgaContent.class);
    }
    
    public void setListLanguage(List<MongoOrgaContent> orgContentlist){
        mongoTemplate.insertAll(orgContentlist);
    }

}
