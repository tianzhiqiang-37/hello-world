/**
 * 
 */
package com.baidu.boot.BootTest;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import org.springframework.scheduling.config.Task;

/**
 * @author 田
 * 2019年2月26日
 */
public class T0031 {
    
    public static void main(String[] args) {
           /*Thread td=new Thread(new Runnable() {
                @Override
                public void run() {
                    System.out.println("线程111111");
                }
            });
           td.start();
           
        Thread t1=new Thread(()->System.out.println("线程222"));
        t1.start();*/
        Stream<String> stream = Stream.of("I", "love", "you", "too");
//        stream.forEach(str -> System.out.println(str));
//        stream.filter(str->str.length()==3).forEach(str->System.out.println(str.substring(2)));//过滤后遍历
//            stream.sorted((str1,str2)->str2.length()-str1.length())
//            .forEach(str->System.out.print("---"+str));//按字符串长短排序后遍历
//            stream.map(str->str.hashCode()).forEach(str->System.out.print("  "+str));//元素映射转换后遍历输出
        
//        Stream<String> s1=Stream.of("aa","bb","cc","aa");
//        s1.distinct().forEach(s->System.out.print("   "+s));  //去重后遍历
            
            /*Stream<List<Integer>> stream = Stream.of(Arrays.asList(2,5), Arrays.asList(1, 3, 6));
            stream.flatMap(list -> list.stream()).forEach(i -> System.out.println(i)); //扁平化映射  */            
//        Optional<String> reduce = stream.reduce((s1,s2)->s1.length()>=s2.length()?s1:s2);//找出length最长元素
//        System.out.println(reduce.get());
        
//        Integer reduce2 = stream.reduce(0,      // 初始值　// (1)
//                (sum,str)->sum+str.length(),    // 累加器 // (2)
//                (a,b)->a+b);                    // 部分和拼接器，并行执行时才会用到 // (3)
//        System.out.println("总长度------"+reduce2);
        
//        List<String> list = stream.collect(Collectors.toList()); // (1)
//         Set<String> collect = stream.collect(Collectors.toSet()); // (1)
//        System.out.println("list"+list.toString());
//        Map<String, Integer> map = stream.collect(Collectors.toMap(Function.identity(), String::length)); // (3)
//        ArrayList<String> arrayList = stream.collect(Collectors.toCollection(ArrayList::new));
//        String collect = stream.collect(Collectors.joining(","));
//        System.out.println(collect);
        Stream<String> map = stream.map(String::toUpperCase);
        /*List names = new ArrayList();
        names.add("Google");
        names.add("Runoob");
        names.add("Taobao");
        names.add("Baidu");
        names.add("Sina");*/
//        map.forEach(System.out::println);
        
        Animal a1 = new Animal();
        a1.setName("小狗");
        a1.setPrice(88);
        Animal a2 = new Animal();
        a2.setName("小喵2");
        a2.setPrice(80);
        Animal a3 = new Animal();
        a3.setName("小喵3");
        a3.setPrice(66);
        Animal a4 = new Animal();
        a4.setName("小喵4");
        a4.setPrice(77);
        Animal a5 = new Animal();
        a5.setName("小喵5");
        a5.setPrice(58);
        
        List<Animal> list = new ArrayList<Animal>();
        list.add(a1);
        list.add(a2);
        list.add(a3);
        list.add(a4);
        list.add(a5);
        list.add(a5);
        List<String> listname = new ArrayList<String>();
        list.stream().forEach(ani->listname.add(ani.getName()));
        System.out.println("动物们名字"+listname.toString());
        Set<String> collect2 = listname.stream().collect(Collectors.toSet());
        for (String string : collect2) {
            System.out.println("去重后---"+string);
        }
        
        
        
        
        List<String> collect = list.stream().map(Animal::getName).collect(Collectors.toList());
        System.out.println("-----"+collect);
        
        
        
//        Set<Animal> collect = list.stream().collect(Collectors.toSet());
//        System.out.println("==========="+collect);
        
//        Stream<Animal> filter = list.stream().filter((aa)->aa.getPrice()<70);
//        filter.forEach(System.out::println);
        
        Optional<Integer> reduce = list.stream().map(Animal::getPrice).reduce(Integer::sum);
        System.out.println("价和"+reduce.get());
        System.gc();//手动GC
//        Stream<Integer> limit = Stream.iterate(0, (x)->x+2).limit(10);
//        limit.forEach(System.out::println);
        
//        Stream<Integer> of = Stream.of(1,2,3,4,5,6,7);
//        of.forEach(System.out::println);
        
    }

}
