/**
 * 
 */
package com.baidu.boot.BootTest;

import java.util.Arrays;
import java.util.IntSummaryStatistics;
import java.util.List;
import java.util.OptionalDouble;
import java.util.Random;
import java.util.stream.Collectors;
import java.util.stream.DoubleStream;
import java.util.stream.Stream;

/**
 * @author 田
 * 2019年3月1日
 */
public class Java8Tester001 {
    
    public static void main(String[] args) {
//        List<String> strings = Arrays.asList("abc", "", "bc", "efg", "abcd", "", "jkl");
//        List<String> filtered = strings.stream().filter(string -> !string.isEmpty()).collect(Collectors.toList());
//        String mergedString = strings.stream().filter(string -> !string.isEmpty()).collect(Collectors.joining(", "));
//        System.out.println("合并字符串: " + mergedString);
        
//        System.out.println(filtered.toString());
        
//        Random random = new Random();
//        random.ints().limit(10).sorted().forEach(System.out::println);
        
        List<Integer> list =Arrays.asList(3, 2, 2, 3, 7, 3, 5);
//        DoubleStream doubleStream = list.stream().mapToInt((x)->x).asDoubleStream();
//        IntSummaryStatistics stats = list.stream().mapToInt((x)->x).summaryStatistics();
//        OptionalDouble findFirst = doubleStream.findFirst();
//        System.out.println("==]===="+findFirst);    
        
//         Stream<Integer> distinct = list.stream().map(i->i*i).distinct();
//         distinct.forEach(str->System.out.println(str+2));
         System.out.println("===============================================");
//         List<Integer> collect = distinct.collect(Collectors.toList());
//        System.out.println("列表中最大的数 : " + stats.getMax());
//        System.out.println("列表中最小的数 : " + stats.getMin());
//        System.out.println("所有数之和 : " + stats.getSum());
//        System.out.println("平均数 : " + stats.getAverage());
         
         List<Integer> ls =Arrays.asList(1,2,3,4,5,6,7,8,9,10);
         Integer reduce = ls.stream().reduce(0, (x,y)->x+y);
         System.out.println("总和====="+reduce);
         
         
         
    }

}
