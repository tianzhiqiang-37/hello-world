/**
 * 
 */
package com.baidu.boot.BootTest;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;

/**
 * @author 田
 * 2019年3月4日
 */
public class T5 {
    
    public static void main(String[] args) throws IOException {
//        String ss="MIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQCyLMIDPuHaVP98t8W4EBzD5xev4LRQop40nAlAWnrrQeUVE+0PzA/wBxOFnErOddOiNvt+L4+j+eUdVZcGcCBJZGGDlE2oVTEbHOQoboy9KKPUJujAWTguCSQny2W6BrkpNiCgf7fuQHKBYwaCCvDTIW6C5JlLtGHhL8O8mrMs67PHPkJQCcj4EgHzjRB245jNDHSfkzvWq2XZIoZTomfqB1k2IkRg3nsmafR6TMUrC4xar2jj0emXlJIbE1cI407nqQWrYnLeUkcdTniTmKFZ2VaZjr6oOlCOVhFcTkffugRTDtt4Cpg6iHNIY9fyzl3W/dbeE7pxk7QmQ99S0AtjAgMBAAECggEBAIsawoYCLBZnUegvGeBwQ+T2oNmhV2W08Esmn1psyZaupYllOymgKbk97RHdSdISz53Py11jCIP+78+NKRHPrIVgJ3mw6UhI6sO+NKsUVDDCb9WMYx75CRF39ZBUDiHEaf8w0Rw9Wn5aNoupokUZAZf0e/EZRE2EkP5cajbvmH+yX+HsOdRqEjSPxg4E5jWQp887uWmq3L6A0RYgBqnsuqM72H+LYLE/FvBPJsKJ+rD0Mv9NEF5l6sbKm4NVGG+wOFq3zcPFp5nD81U/2V+wdzcJZDrLHCbrS4/r3uTlPYLxJhsh7SvWh9DF8x/G9ilaSJfZV4s5Dnyduv0nvVQSpFECgYEA2m9FtLDoELgAxuchob/W3vFsFvOTMLTHmc7giC7hVTXQBhUzHDYZ8bDD4lHQSfrmWhG7HmPnwlGpYyvLNuzNy5DlTcXuiBlMzMhfGGE6ByiaobIIXtBrzgmvaxmPzxlhT5lMVDCoC3zBgmj6M0Po4wd+1sTQLBzz941reDSJ0CUCgYEA0NEFUBuI6kfDNKzhplwTMYSXSWGmQHYCBOcy7cXfzPfEv/52QWQETvGXL4oJjwlddssAFJtICjXUwcXC2RvPgZ+DFUAbHHm70D4p/dgAFcRUX+1ScfcCmh4lTzql4idjPNrIGcHeJ1FEJ5IFVkUA/P8O2VSCnor/vhBH7zg2MucCgYEAxGB7M3pD+Bvknu1WgBt/KomzWmL69jPgqrehhu1WqYuqjH1sqLU+19nKEWLqNkh55YnBRw4cYseV2FGb7bIxRgzrCeOjkfnk4MpXLAzk5WCsvCfZfJw1/1MXwNqHPnIb2TsBs0LXIRS0x/Bm18X6zniDoMPqP258KxeaAcSCDX0CgYB4vuTblZBuKGDwLKeukr9mes0gWZ7Q12wDec0xQKJQ21Sh0HqBBVyYaYqKqr8sPrYU4v2A7OmTPd1wzvIEqNgslBgwSYljxeCcYdXWOviRnZ1MeuaZj8OpapUYY0lYpH31ymy6uCfFhHBskTsUz4HqyXHEqeF929JWDQQLh+2PMQKBgBgrUgDXK3XNQkHwM7JEoDhNR62FF+33OPcCSGw9xEZ+BrQ3SfnaHCEoLQ7QZ4kBt0/SXsyKHEd/CjkJPGxvCNzr0uSc7iIIuZ7trmRCezUD9RTHDiZyGCHQNZDhnlLNjfMT60xhBuFbfGB2dhui+t/xR8ySQf4qEZMTLUiQuNZi";
//        String sw="MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAsizCAz7h2lT/fLfFuBAcw+cXr+C0UKKeNJwJQFp660HlFRPtD8wP8AcThZxKznXTojb7fi+Po/nlHVWXBnAgSWRhg5RNqFUxGxzkKG6MvSij1CbowFk4LgkkJ8tluga5KTYgoH+37kBygWMGggrw0yFuguSZS7Rh4S/DvJqzLOuzxz5CUAnI+BIB840QduOYzQx0n5M71qtl2SKGU6Jn6gdZNiJEYN57Jmn0ekzFKwuMWq9o49Hpl5SSGxNXCONO56kFq2Jy3lJHHU54k5ihWdlWmY6+qDpQjlYRXE5H37oEUw7beAqYOohzSGPX8s5d1v3W3hO6cZO0JkPfUtALYwIDAQAB";
//        System.out.println("*********"+ss.length());
       InputStream resourceAsStream = T5.class.getClassLoader().getResourceAsStream("application.yml");
       BufferedReader br= new BufferedReader(new InputStreamReader(resourceAsStream));
       String readLine= null;
       StringBuilder sb= new StringBuilder();
       while((readLine= br.readLine())!=null){
           if(readLine.charAt(0)=='-'){
               continue;
           }else{
               sb.append(readLine);
               sb.append('\r');
           }
       }
        System.out.println();
    }

}
