/**
 * 
 */
package com.baidu.boot.BootTest;

/**
 * @author 田
 * 2018年7月6日
 */
public class Animal {
	private String name;
    private int price;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

//    public Animal(String name, int price) {
//        this.name = name;
//        this.price = price;
//    }

    @Override
    public String toString() {
        return "Animal [name=" + name + ", price=" + price + "]";
    }
    
    
    
}
