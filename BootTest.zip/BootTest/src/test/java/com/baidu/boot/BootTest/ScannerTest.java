/**
 * 
 */
package com.baidu.boot.BootTest;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

/**
 * @author 田
 * 2019年5月7日
 */
public class ScannerTest {
    
    public static void main(String[] args) throws IOException {
        /*Scanner scan = new Scanner(System.in);
     // next方式接收字符串
        System.out.println("next方式接收：");
        // 判断是否还有输入
        if (scan.hasNext()) {
            String str1 = scan.next();
//            String str1 = scan.nextLine();
            System.out.println("输入的数据为：" + str1);
        }
        scan.close();*/
        
        char c;
        // 使用 System.in 创建 BufferedReader
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("输入字符, 按下 'q' 键退出。");
        // 读取字符
        do {
            c = (char) br.read();
            System.out.println(c);
        } while (c != 'q');
    }

}
