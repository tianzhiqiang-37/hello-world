/**
 * 
 */
package com.baidu.boot.BootTest;

import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import freemarker.template.Configuration;
import freemarker.template.Template;

/**
 * @author 田
 * 2018年7月5日
 */
public class TestFreemark{
	
	public static void main(String[] args) {
		/* try {
	            // 创建插值的map
	            Map<String,Object> map = new HashMap<String,Object>();
	            map.put("user", "rr");
	            map.put("url", "http://www.baidu.com/");
	            map.put("name", "百度");

	            // 创建一个模板对象
	            Template t = new Template(null, new StringReader("用户名：${user};URL：    ${url};姓名： 　${name}"), null);

	            // 执行插值，并输出到指定的输出流中
	            Writer writer = new FileWriter("D:\\aa.html");
	            t.process(map, writer);
	            // t.process(map, new OutputStreamWriter(System.out));
	        } catch (Exception e) {
	            e.printStackTrace();
	        }*/
		
		  Animal a1 = new Animal();
	        a1.setName("小狗");
	        a1.setPrice(88);
	        Animal a2 = new Animal();
	        a2.setName("小喵");
	        a2.setPrice(80);

	        List<Animal> list = new ArrayList<Animal>();
	        list.add(a1);
	        list.add(a2);
	        
	        Map<String,Object> sexMap=new HashMap<String,Object>();
	        sexMap.put("1", "男");
	        sexMap.put("0","女");

	        Map<String,Object> map = new HashMap<String,Object>();
	        map.put("user", "冉冉");
	        map.put("score", 10);
	        map.put("team", "一班,二班");
	        map.put("animals", list);
	        map.put("sexMap",sexMap);
	        try {
	            Configuration config = new Configuration();
	            
	            config.setDefaultEncoding("UTF-8");
	            config.setDirectoryForTemplateLoading(new File("D:\\RuanJian"));
	            
//	            HttpServletRequest request = ServletActionContext.getRequest();
	            config.setServletContextForTemplateLoading("", "");
	            
	            
	            Template template = config.getTemplate("hello.ftl");
	            template.process(map,new FileWriter("D:\\bbb.html"));
	        } catch (Exception e) {
	            // TODO: handle exception
	            e.printStackTrace();
	        }
	}
	
}
