/**
 * 
 */
package com.baidu.boot.BootTest;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import java.util.Optional;
import org.junit.Test;

/**
 * @author 田
 * 2019年2月26日
 */
public class Test002 {
    
    @Test
    public void whenCreateOfNullableOptional_thenOk() {
        Author user = new Author();
//        user.setEmail("tian@dwnews.com");
//        user.setName("田");
//        Optional<Author> opt = Optional.ofNullable(user);
//        System.out.println("==========="+opt);
//        assertTrue(opt.isPresent());
//        assertEquals(user.getEmail(), opt.get().getEmail());
        /*String name = "";
        Optional<String> opt = Optional.ofNullable(name);
        System.out.println("========"+opt);
        assertEquals("John", opt.get());*/
        
    }
    
    public static void main(String[] args) {
       /* int x=10;
        System.out.println("Testing Assertion that x==100");
        assert x==100:"Out assertion failed!";
        System.out.println("Test passed!");*/
        /*boolean isEnable=false;
        assert isEnable=true;
          if(isEnable==false){
              throw new RuntimeException("Assertion should be enabled!");
          }*/
        Comparator<String> comparator = (first, second) -> System.out.println(Integer.compare(first.length(), second.length())); //编译会出错
        comparator.com("aaaaa","bb");
   }
    
        public interface Comparator<T> {
            void com(String a,String b);
        }

}
